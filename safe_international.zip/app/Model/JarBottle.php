<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class JarBottle extends Model
{
   protected $fillable=['title','price','image','description'];
}
