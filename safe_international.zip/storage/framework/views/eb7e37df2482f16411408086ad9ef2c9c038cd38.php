<?php $__env->startSection('additionalCSS'); ?>
    <style>
        .client img {
            width: 100%;
            height: 250px;
            object-fit: cover;
        }

        .client {
            border: 1px solid #eee;
            padding: 5px 5px;
            margin: 15px 0;
            box-shadow: 0 0 5px 0 #e6e6e6;
            border-radius: 5px;
            transition: all 500ms ease;
        }
        .client:hover{
            box-shadow: 0 0 7px 0 #e6e6e6;
            opacity: 0.7;
        }

        .client-text {
            text-align: center;
        }

        h5.card-title {
            font-size: 22px;
            text-transform: capitalize;
            font-weight: bold;
            margin: 0;
            padding: 3px 0;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="hero-wrap hero-wrap-2" style="background-image: url('<?php echo e(asset('themes/front/images/bg_1.jpg')); ?>');">
        <div class="overlay"></div>
        <div class="container">
            <div class="row no-gutters slider-text align-items-center justify-content-center">
                <div class="col-md-9 ftco-animate text-center fadeInUp ftco-animated">
                    <h1 class="mb-2 bread">Clients</h1>
                </div>
            </div>
        </div>
    </section>
    <section class="client-sections">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <div title="<?php echo e($client->name); ?>" class="client">
                            <img src="<?php echo e(asset('uploads/client/'.$client->image)); ?>"  alt="<?php echo e($client->name); ?>">
                            <div class="client-text">
                                <h5 class="card-title"><?php echo e($client->name); ?></h5>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <?php echo e($clients->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\safe_international\resources\views/clients.blade.php ENDPATH**/ ?>