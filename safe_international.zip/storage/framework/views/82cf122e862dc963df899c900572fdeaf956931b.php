<?php $__env->startSection('additionalCSS'); ?>

    <style>
        .machine-content {
            overflow: hidden;
            border: 1px solid #eee;
            text-align: center;
            margin: 15px 0px;
            background-color: #fafafa;
            padding: 15px 0;
        }

        .machine-img img {
            min-width: 100%;
            height: 250px;
            object-fit: contain;
            border: 1px solid #ddd;
            padding: 6px 4px;
        }

        .machine-model {
            text-align: left;
            font-weight: bold;
            padding: 10px 15px;
            border-bottom: 1px dotted #e1e1e1;
            text-transform: capitalize;
        }

        .ftco-section {
            padding: 25px !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="hero-wrap hero-wrap-2" style="background-image: url('<?php echo e(asset('themes/front/images/bg_1.jpg')); ?>');">
        <div class="overlay"></div>
        <div class="container">
            <div class="row no-gutters slider-text align-items-center justify-content-center">
                <div class="col-md-9 ftco-animate text-center fadeInUp ftco-animated">
                    <h1 class="mb-2 bread">Machines</h1>
                </div>
            </div>
        </div>
    </section>

    <section class="ftco-section">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12">
                    <div class="row machine-content">
                        <h2 class="col-sm-12 machine-model">Model: <?php echo e($machine->model); ?></h2>
                        <div class="col-sm-4 machine-img">
                            <img src="<?php echo e(asset('uploads/machine/'.$machine->image1)); ?>" alt="">
                        </div>
                        <div class="col-sm-6 machine-text">
                        <h4 class="machine-type">Machine Type: <?php echo e($machine->type); ?></h4>
                        <h4 class="machine-capacity">Machine Capacity: <?php echo e($machine->capacity); ?></h4>
                        <p class="machine-description"><?php echo $machine->description; ?></p>
                            <a href="<?php echo e(route('machine.details',$machine->id)); ?>" class="btn btn-info machine-btn">More</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php echo e($machines->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\safe_international\resources\views/all_machine.blade.php ENDPATH**/ ?>