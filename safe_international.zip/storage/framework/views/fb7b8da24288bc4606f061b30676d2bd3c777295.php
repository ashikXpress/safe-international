<?php $__env->startSection('title'); ?>
    Add Machine
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Machine Information</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal" method="POST" enctype="multipart/form-data" action="<?php echo e(route('add.machine')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="box-body">


                        <div class="form-group <?php echo e($errors->has('model') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Model</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter model"
                                       name="model" value="<?php echo e(old('model')); ?>">

                                <?php if ($errors->has('model')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('model'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('type') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Type</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter type"
                                       name="type" value="<?php echo e(old('type')); ?>">

                                <?php if ($errors->has('type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('type'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('capacity') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Capacity</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter capacity"
                                       name="capacity" value="<?php echo e(old('capacity')); ?>">

                                <?php if ($errors->has('capacity')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('capacity'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('image1') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Image 1</label>

                            <div class="col-sm-10">
                                <input type="file" class="form-control" name="image1">

                                <?php if ($errors->has('image1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image1'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('image2') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Image 2</label>

                            <div class="col-sm-10">
                                <input type="file" class="form-control" name="image2">

                                <?php if ($errors->has('image2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image2'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('image3') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Image 3</label>

                            <div class="col-sm-10">
                                <input type="file" class="form-control" name="image3">

                                <?php if ($errors->has('image3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image3'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('description') ? 'has-error' :''); ?>">
                            <label class="col-sm-2 control-label">Description</label>

                            <div class="col-sm-10">
                                <textarea id="editor1" name="description" rows="10" cols="80"><?php echo e(old('description')); ?></textarea>

                                <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                                <span class="help-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additionalJS'); ?>
    <!-- CK Editor -->
    <script src="<?php echo e(asset('themes/back/bower_components/ckeditor/ckeditor.js')); ?>"></script>
    <script>
        $(function () {
            CKEDITOR.replace('editor1');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\safe_international\resources\views/admin/machine/add_machine.blade.php ENDPATH**/ ?>