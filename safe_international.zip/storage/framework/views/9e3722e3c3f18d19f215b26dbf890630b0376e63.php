<?php $__env->startSection('content'); ?>
    <section class="home-slider owl-carousel">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="slider-item" style="background-image:url('<?php echo e(asset('uploads/slider/'.$slider->image)); ?>');">
                <div class="overlay"></div>
                <div class="container">
                    <div class="row no-gutters slider-text align-items-center justify-content-start" data-scrollax-parent="true">
                        <div class="col-md-7 ftco-animate">
                            <span class="subheading"><?php echo e($slider->subheading); ?></span>
                            <h1 class="mb-4"><?php echo e($slider->heading); ?></h1>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>

    <section class="ftco-section">
        <div class="container">
            <div class="row d-flex">
                <div class="col-md-5 order-md-last wrap-about align-items-stretch">
                    <div class="wrap-about-border ftco-animate">
                        <div class="img" style="background-image: url('<?php echo e(asset('img/dtcl.jpg')); ?>'); border"></div>
                        <div class="text">
                            <h3>Read Our Success Story for Inspiration</h3>
                            <p>Bangladesh, like the most developing countries, had to import comparatively high cost expatriate technical manpower for development initiation like feasibility studies, planning, design, tender documents preparation and construction supervision. However, it began, like the other developing countries, to develop its own expertise in different development fields. Higher technical and management know-how has been acquired over the years, either by co-working with or working directly under the guidance of the expatriates. To fill up the existing void in the technical know-how, and eventually to fulfil the development needs of the country by experts, DTCL initially started as Proprietorship Company in 2001 which later incorporated as limited company in 2007 under the office of the registrar of joint stock companies of Bangladesh.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-7 wrap-about pr-md-4 ftco-animate">
                    <h2 class="mb-4">Introduction</h2>
                    <p>Development Technical Consultants Pvt. Ltd. (DTCL) is an ISO 9001:2015 leading consulting firm of Bangladesh founded in 2001. Appropriate and adequate technical know-how is one of the pre-requisites for the development of the country. But its lack has greatly hampered the country’s development work - a common phenomenon observed in all developing countries. Hence, the increase in technical capabilities, both qualitative and quantitative, of Bangladeshi professionals’ needs immediate attention, Economic development of the country is in fact directly proportional to its technical capabilities. DTCL is duly registered with ADB through CMS No. 012563 and the World Bank including other bilateral and multilateral donors and government agencies.</p>
                    <div class="row mt-5">
                        <div class="col-lg-6">
                            <div class="services active text-center">
                                <div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-collaboration"></span></div>
                                <div class="text media-body">
                                    <h3>Agricultural, Fisheries & Livestock</h3>
                                    <p>With significant experience spanning farm to market, including policy, value chain analysis, research and extension, production, shipment and storage, marketing, agribusiness & supply chain development.</p>
                                    <br>
                                    <br>
                                </div>
                            </div>
                            <div class="services text-center">
                                <div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-analysis"></span></div>
                                <div class="text media-body">
                                    <h3>Social Development</h3>
                                    <p>Focusing on developing and strengthening the capacity of cooperatives, NGOs, associations and other organizations in rural and urban settings to improve the participation and representation of the poor and women in their own development.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="services text-center">
                                <div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-search-engine"></span></div>
                                <div class="text media-body">
                                    <h3>Education & Training</h3>
                                    <p>Including pre-primary, primary, secondary and tertiary education as well as non-formal, technical and vocational education & training (TVET) policy, planning, management, curriculum development & evaluation, training and project formulation & implementation with strong experience at all levels.</p>
                                </div>
                            </div>
                            <div class="services text-center">
                                <div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-handshake"></span></div>
                                <div class="text media-body">
                                    <h3>Forest & Environment</h3>
                                    <p>With significant experience in forest resource management, forest resource monitoring and assessment, management information system (MIS), GIS, land use mapping, assessment and monitoring of afforestation and reforestation monitoring, climate change, adaptation etc.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="ftco-intro ftco-no-pb img" style="background-image: url('<?php echo e(asset('themes/front/images/bg_3.jpg')); ?>');">
        <div class="container">
            <div class="row justify-content-center mb-5">
                <div class="col-md-10 text-center heading-section heading-section-white ftco-animate">
                    <h2 class="mb-0">You Always Get the Best Guidance</h2>
                </div>
            </div>
        </div>
    </section>

    <section class="ftco-counter" id="section-counter">
        <div class="container">
            <div class="row d-md-flex align-items-center justify-content-center">
                <div class="wrapper">
                    <div class="row d-md-flex align-items-center">
                        <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
                            <div class="block-18">
                                <div class="icon"><span class="flaticon-doctor"></span></div>
                                <div class="text">
                                    <strong class="number" data-number="705">0</strong>
                                    <span>Projects Completed</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
                            <div class="block-18">
                                <div class="icon"><span class="flaticon-doctor"></span></div>
                                <div class="text">
                                    <strong class="number" data-number="809">0</strong>
                                    <span>Satisfied Customer</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
                            <div class="block-18">
                                <div class="icon"><span class="flaticon-doctor"></span></div>
                                <div class="text">
                                    <strong class="number" data-number="335">0</strong>
                                    <span>Awwards Received</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
                            <div class="block-18">
                                <div class="icon"><span class="flaticon-doctor"></span></div>
                                <div class="text">
                                    <strong class="number" data-number="35">0</strong>
                                    <span>Years of Experienced</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center mb-5 pb-2">
                <div class="col-md-8 text-center heading-section ftco-animate">
                    <h2 class="mb-4">Our Best Services</h2>
                    <p>The Company has completed a large number of projects of different fields. Some of them are nearing completion. Among the completed ones are prestigious projects financed by the World Bank, Asian Development Bank, ODA and other international organisations. All projects have been or are being carried out either independently or in collaboration with other local consultants and/or international firms.</p>
                </div>
            </div>
            <div class="row no-gutters">
                <div class="col-lg-4 d-flex">
                    <div class="services-2 noborder-left text-center ftco-animate">
                        <div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-analysis"></span></div>
                        <div class="text media-body">
                            <h3>Power & Energy</h3>
                            <p>With significant experience in generation, transmission and distribution, planning and management, policy development, efficiency improvement, reduction of loss, and exploration under subsector of Coal, Oil, Gas, Power, Energy, LNG & LPG.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 d-flex">
                    <div class="services-2 text-center ftco-animate">
                        <div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-business"></span></div>
                        <div class="text media-body">
                            <h3>Information & Communication Technology</h3>
                            <p>Spanning data collection using tab and mobile apps, information management system including design, development & implementation, customization; financial accounting & inventory management, payroll management; IT support management, network management, web system development, software development etc.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 d-flex">
                    <div class="services-2 text-center ftco-animate">
                        <div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-insurance"></span></div>
                        <div class="text media-body">
                            <h3>Infrastructure & Transport</h3>
                            <p>Covering all aspects of infrastructure development includes ‘Rural & Urban, Roads, Bridge, Culverts, Rail, Shipping and Port & Harbor’.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 d-flex">
                    <div class="services-2 noborder-left noborder-bottom text-center ftco-animate">
                        <div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-money"></span></div>
                        <div class="text media-body">
                            <h3>Infrastructure Development</h3>
                            <p>Infrastructure Development covering all aspects of infrastructure development includes Rural and Urban, Roads, Bridge, Culverts, Rail, Port and Harbour.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 d-flex">
                    <div class="services-2 text-center noborder-bottom ftco-animate">
                        <div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-rating"></span></div>
                        <div class="text media-body">
                            <h3>Water Resource, Water Supply & Sanitation</h3>
                            <p>Including water resource management, water supply, sanitation, urban development engineering and infrastructure.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 d-flex">
                    <div class="services-2 text-center noborder-bottom ftco-animate">
                        <div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-search-engine"></span></div>
                        <div class="text media-body">
                            <h3>Health and Population</h3>
                            <p>Covering health, family welfare and population sector. The service in the field includes general health, primary health, maternal health, nutrition, and family planning feasibility study, design, capacity building, project implementation, monitoring and evaluation, impact assessment, survey and other development studies.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="ftco-section ftco-no-pb">
        <div class="container-fluid px-0">
            <div class="row no-gutters justify-content-center mb-5">
                <div class="col-md-7 text-center heading-section ftco-animate">
                    <h2 class="mb-4">Our Recent Projects</h2>
                    <p>Development Technical Consultants Pvt. Ltd. (DTCL) has worked nearly about 171 different projects funded by different donor organizations including governments of the respective countries. The firm has diversified field of experience working in almost all development sectors of Bangladesh, Bhutan, Nepal, Indonesia and Sri Lanka. The firm has also worked in number of projects for most of the donors such as ADB, WB, DFID, UNDP, FAO, JICA, EU, CIDA, USAID, SIDA, IFC, GEF, UNICEF and other bilateral and government financed projects. Being the country’s premium development consultancy firm Firm’s has a wide project experience in home as well as in abroad. A list of general experience of the firm is given below: </p>
                    <p></p>
                </div>
            </div>
            <div class="row no-gutters">
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                    <div class="project img ftco-animate d-flex justify-content-center align-items-center" style="background-image: url('<?php echo e(asset('uploads/project/'.$project->image)); ?>');">
                        <div class="overlay"></div>
                        <a href="<?php echo e(route('project_details', ['id' => $project->id])); ?>" class="btn-site d-flex align-items-center justify-content-center"><span class="icon-subdirectory_arrow_right"></span></a>
                        <div class="text text-center p-4">
                            <h3><a href="<?php echo e(route('project_details', ['id' => $project->id])); ?>"><?php echo e($project->title); ?></a></h3>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section class="ftco-section bg-light">
        <div class="container">
            <div class="row justify-content-center mb-5 pb-2">
                <div class="col-md-8 text-center heading-section ftco-animate">
                    <h2 class="mb-4"><span>Recent</span> News</h2>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $newses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4 ftco-animate">
                        <div class="blog-entry">
                            <a href="<?php echo e(route('news_details', ['id' => $news->id])); ?>" class="block-20 d-flex align-items-end" style="background-image: url('<?php echo e(asset('uploads/news/image/'.$news->image)); ?>');">
                                <div class="meta-date text-center p-2">
                                    <span class="day"><?php echo e(date("d", strtotime($news->uploaded_at))); ?></span>
                                    <span class="mos"><?php echo e(date("F", strtotime($news->uploaded_at))); ?></span>
                                    <span class="yr"><?php echo e(date("Y", strtotime($news->uploaded_at))); ?></span>
                                </div>
                            </a>
                            <div class="text bg-white p-4">
                                <h3 class="heading"><a href="<?php echo e(route('news_details', ['id' => $news->id])); ?>"><?php echo e($news->title); ?></a></h3>
                                <p><?php echo Str::words($news->description, 15); ?></p>
                                <div class="d-flex align-items-center mt-4">
                                    <p class="mb-0"><a href="<?php echo e(route('news_details', ['id' => $news->id])); ?>" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                                    <p class="ml-auto mb-0">
                                        <?php echo e($news->author); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section class="ftco-section testimony-section">
        <div class="container">
            <div class="row justify-content-center mb-5">
                <div class="col-md-8 text-center heading-section ftco-animate">
                    <h2 class="mb-4">Our Clients Says</h2>
                </div>
            </div>
            <div class="row ftco-animate justify-content-center">
                <div class="col-md-12">
                    <div class="carousel-testimony owl-carousel">
                        <?php $__currentLoopData = $says; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $say): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="testimony-wrap d-flex">
                                    <div class="user-img" style="background-image: url('<?php echo e(asset('uploads/says/'.$say->image)); ?>')">
                                    </div>
                                    <div class="text pl-4">
                                        <span class="quote d-flex align-items-center justify-content-center">
                                          <i class="icon-quote-left"></i>
                                        </span>
                                        <p style="white-space: pre-wrap"><?php echo e($say->description); ?></p>
                                        <p class="name"><?php echo e($say->author); ?></p>
                                        <span class="position"><?php echo e($say->designation); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dtcl\resources\views/home.blade.php ENDPATH**/ ?>