<?php $__env->startSection('additionalCSS'); ?>
    <link href="<?php echo e(asset('plugins/lightbox2/css/lightbox.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="hero-wrap hero-wrap-2" style="background-image: url('<?php echo e(asset('themes/front/images/bg_1.jpg')); ?>');">
        <div class="overlay"></div>
        <div class="container">
            <div class="row no-gutters slider-text align-items-center justify-content-center">
                <div class="col-md-9 ftco-animate text-center fadeInUp ftco-animated">
                    <h1 class="mb-2 bread">Gallery</h1>
                </div>
            </div>
        </div>
    </section>

    <section class="ftco-section">
        <div class="container">
            <?php $__currentLoopData = $items->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row mb-3">
                    <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3">
                            <a href="<?php echo e(asset('uploads/gallery/'.$item->image)); ?>" data-lightbox="album" data-title="<?php echo e($item->title); ?>" data-alt="<?php echo e($item->title); ?>">
                                <img src="<?php echo e(asset('uploads/gallery/thumbs/'.$item->image)); ?>" class="img-thumbnail">
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo e($items->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additionalJS'); ?>
    <script src="<?php echo e(asset('plugins/lightbox2/js/lightbox.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\safe_international\resources\views/gallery.blade.php ENDPATH**/ ?>