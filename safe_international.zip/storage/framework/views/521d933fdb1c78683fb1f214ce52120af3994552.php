<?php $__env->startSection('content'); ?>
    <section class="hero-wrap hero-wrap-2" style="background-image: url('<?php echo e(asset('themes/front/images/bg_1.jpg')); ?>');">
        <div class="overlay"></div>
        <div class="container">
            <div class="row no-gutters slider-text align-items-center justify-content-center">
                <div class="col-md-9 ftco-animate text-center fadeInUp ftco-animated">
                    <h1 class="mb-2 bread">News</h1>
                </div>
            </div>
        </div>
    </section>

    <section class="ftco-section bg-light">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $newses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4 ftco-animate">
                        <div class="blog-entry">
                            <a href="<?php echo e(route('news_details', ['id' => $news->id])); ?>" class="block-20 d-flex align-items-end" style="background-image: url('<?php echo e(asset('uploads/news/image/'.$news->image)); ?>');">
                                <div class="meta-date text-center p-2">
                                    <span class="day"><?php echo e(date("d", strtotime($news->uploaded_at))); ?></span>
                                    <span class="mos"><?php echo e(date("F", strtotime($news->uploaded_at))); ?></span>
                                    <span class="yr"><?php echo e(date("Y", strtotime($news->uploaded_at))); ?></span>
                                </div>
                            </a>
                            <div class="text bg-white p-4">
                                <h3 class="heading"><a href="<?php echo e(route('news_details', ['id' => $news->id])); ?>"><?php echo e($news->title); ?></a></h3>
                                <p><?php echo Str::words($news->description, 15); ?></p>
                                <div class="d-flex align-items-center mt-4">
                                    <p class="mb-0"><a href="<?php echo e(route('news_details', ['id' => $news->id])); ?>" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                                    <p class="ml-auto mb-0">
                                        <?php echo e($news->author); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php echo e($newses->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dtcl\resources\views/news.blade.php ENDPATH**/ ?>